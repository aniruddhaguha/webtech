<?php	
 print_r ($GLOBALS);
	$firstname=trim($_POST['firstname']);
	$lastname=trim($_POST['lastname']);
	$day=trim($_POST['dd']);
	$mon=trim($_POST['mm']);
	$year=trim($_POST['yyyy']);
	//$gender=trim($_POST['gender']);
	$phone=trim($_POST['phone']);
	$email=trim($_POST['email']);
	$password=trim($_POST['password']);
	$conpassword=trim($_POST['conpassword']);
	
	//echo "$firstname";

	
	//Empty or not!!
	if (empty($firstname) ||empty($lastname) ||  empty($day) || empty($mon) || empty($year)|| empty($_POST['gender'])  || empty($phone)|| empty($email) ||  empty($password) || empty($conpassword) )
	{
		echo "No field can't be empty";
	}
	
	
	elseif(isset($_POST ['Submit'])){
		$count=str_word_count($firstname);
		if ($count < 2) {
			echo "firstName at least 2 word";
		}
		else{

			 if(is_numeric($firstname[0]))
			 {
			 	echo "firstName can not be emapty";
			 }
			 else
			 {
			 	if (!preg_match("/^[a-zA-Z ]*$/",$firstname)) 
				{
					 echo "Only a-z & A-Z can be used";
				}
				else
				{
					//Username validation
					$count=str_word_count($lastname);
					if ($count < 2) {
						echo "lastName at least 2 word";
					}
					else{

						 if(is_numeric($lastname[0]))
						 {
							echo "firstName can not be emapty";
						 }
						 else
						 {
							if (!preg_match("/^[a-zA-Z ]*$/",$lastname)) 
							{
								 echo "Error";
							}
							else
							{
								//password
								if(strlen($password)<8)
								{
								echo "Password at least 8 character";
								}
								else
								{
									//Confirm Password
									if( $password !== $conpassword)
									{
									echo "Password is not matched";
									}
									else
									{
										//gender
										$gender=$_POST['gender'];
										if(empty($gender))
										{
											echo "Error";
										}
										else
										{
											//DOB
											if($day<1 || $day>31)
											{
												echo "Day must between 1-31";
											}
											else
											{
												if($mon<1 || $mon>12)
												{
													echo "Month must be 1-12 range";
												}
												else
												{
													if($year<1953 || $year>2018)
													{
														echo "Year must be 1953-2018 range";
													}
													//Email check
													else
													{
														if(!empty($_POST['email']))
																{     
																	   $str =$_POST['email']; 
																	   if (strspn($str,"@")<=0)
																			   {
																					if(substr_count($str,"@")==1)
																     			  {
																						$str =$_POST['email']; 
																						$arr_email=explode("@",$str);
																						if (count($arr_email)>=2) 
																							{
																								$last_index=$arr_email[count($arr_email)-1];
																								$arr_email=explode(".",$last_index);
																								if (count($arr_email)>=2) 
																								   {
																										 if ($arr_email[0]=="") 
																										 {
																											echo " Ivalid Email Address"."<br/>";
																										 }
																										 elseif ($arr_email[count($arr_email)-1]=="") 
																										 {
																											echo " Ivalid Email Address"."<br/>";
																										 }
																										 else
																										 {
																												if (stristr($str,".com")==".com") 
																													   {
																															$email = $_POST['email'];
																															//echo "Email: ".$email."<br/>";

																													   }
																													   else
																													   {
																															echo "Invalid Email Address"."<br/>";
																													   }
																											
																										 }

																								   }
																								else
																								   {
																									   echo " Ivalid Email Address"."<br/>";
																								   }

																							}
																						else
																						{
																							echo " Ivalid Email Address"."<br/>";
																						}

																					}
																					else
																					{
																					   echo " Ivalid Email Address"."<br/>";
																					}					
																			 }	
																			 else
																				{
																				   echo " Ivalid Email Address"."<br/>";
																				}
																	 }
														else
														{
															
														}
													}
												}
											}
										}
									}
								}
							}
						 }
					}
				}
			 }
		}
	}
?>
<html>
	<head>
		<title>Registration</title>
    </head>
	<body>
	<center>
		<table>
			<td>
				<form action="Registration Validation.php" method="post">
					<fieldset>
					<legend>Registration</legend>
						<table>
							<tr>
								<td><label> First Name &nbsp &nbsp &nbsp &nbsp </label></td>
								<td>:<input type="text" name="firstname"/></td>
							</tr>
							<tr>
								<td><label>Last Name &nbsp &nbsp &nbsp</label></td>
								<td>:<input type="text" name="lastname"/></td>
							</tr>
							<tr>
								<td colspan='2'>
									<fieldset>
									<legend>Date of Birth</legend>
										<table>
											<tr>
												<td>
												<input type="text"  name="dd"/>/
												<input type="text"  name="mm"/>/
												<input type="text"  name="yyyy"/>
												</td>
												<td>(dd/mm/yyyy)</td>
											</tr>
										</table>
									</fieldset>
								</td>
							</tr>
							<tr>
								<td colspan='2'>
									<fieldset>
									<legend>Gender</legend>
										
											<tr>
												<td>
												<input type="radio" value="Male" name="gender"/>Male
												<input type="radio" value="Female" name="gender"/>Female
												<input type="radio" value="Other" name="gender"/>other
												</td>
											</tr>
										
									</fieldset>
								</td>
							</tr>
							
							<tr>
								<td colspan='2'><hr/></td>
							</tr>
							<tr>
								<td><label>Phone &nbsp &nbsp &nbsp &nbsp</label></td>
								<td>:<input type="text" name="phone"/></td>
							</tr>
							<tr>
								<td><label>Email &nbsp &nbsp &nbsp &nbsp</label></td>
								<td>:<input type="text" name="email"/></td>
							</tr>
							<tr>
								<td colspan='2'><hr/></td>
							</tr>
							
							<tr>
								<td colspan='2'><hr/></td>
							</tr>
							<tr>
								<td><label>Password &nbsp &nbsp &nbsp</label></td>
								<td>:<input type="password" name="password"/></td>
							</tr>
							<tr>
								<td colspan='2'><hr/></td>
							</tr>
							<tr>
								<td><label>Confirm Password &nbsp &nbsp</label></td>
								<td>:<input type="password" name="conpassword"/></td>
							</tr>
							<tr>
								<td colspan='2'><hr/></td>
							</tr>
							
							<tr>
								<td colspan='2'><hr/></td>
							</tr>
							
							<tr>
								<td colspan='2'><hr/></td>
							</tr>
							<tr>
								<td><input type="Submit" value="Submit" name="Submit"/>
								<input type="Reset" value="Reset" name="Reset"/></td>
							<tr>
						</table>
					</fieldset>
				</form>
			</td>
		</table>
		</center>
	</body>
</html>